package com.mlp.watson.core;

public interface MillenniumTest {
}
